# Synthetic review fixture. Never deploy or execute this service.
from flask import Flask, request
import subprocess
app = Flask(__name__)

@app.get("/diagnostic")
def diagnostic():
    return subprocess.check_output(request.args["command"], shell=True, text=True)
